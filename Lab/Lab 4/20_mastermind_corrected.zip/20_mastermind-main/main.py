from game import Mastermind


def choose_difficulty():
    print("\nChoose difficulty:")
    print("1. Easy   - 4 digits, symbols 1-6, 10 turns")
    print("2. Medium - 5 digits, symbols 1-8, 10 turns")
    print("3. Hard   - 6 digits, symbols 1-9, 12 turns")

    while True:
        choice = input("Enter choice (1-3): ").strip()

        if choice == "1":
            return "Easy"

        if choice == "2":
            return "Medium"

        if choice == "3":
            return "Hard"

        print("Invalid choice. Enter 1, 2, or 3.")


if __name__ == "__main__":
    difficulty = choose_difficulty()
    game = Mastermind(difficulty)
    game.run()