import random
from logic import feedback


class Mastermind:
    def __init__(self, difficulty="Easy"):
        self.difficulty = difficulty

        if difficulty == "Easy":
            self.code_length = 4
            self.symbol_max = 6
            self.max_turns = 10

        elif difficulty == "Medium":
            self.code_length = 5
            self.symbol_max = 8
            self.max_turns = 10

        else:  # Hard
            self.code_length = 6
            self.symbol_max = 9
            self.max_turns = 12

        self.code = [
            str(random.randint(1, self.symbol_max))
            for _ in range(self.code_length)
        ]

        self.history = []
        self.turns = self.max_turns
        self.game_over = False
        self.won = False

    def display_history(self):
        if not self.history:
            return

        print("\nGuess History")
        print("-" * 35)

        for number, (guess, exact, partial) in enumerate(self.history, 1):
            print(
                f"{number}. {guess} "
                f"-> Exact: {exact}, Partial: {partial}"
            )

        print("-" * 35)

    def valid_guess(self, raw):
        return (
            len(raw) == self.code_length
            and raw.isdigit()
            and all(
                "1" <= ch <= str(self.symbol_max)
                for ch in raw
            )
        )

    def run(self):
        print("\n==============================")
        print("        MASTERMIND")
        print("==============================")
        print(f"Difficulty : {self.difficulty}")
        print(f"Code length: {self.code_length}")
        print(f"Symbols    : 1-{self.symbol_max}")
        print(f"Turns      : {self.max_turns}")
        print("Type 'q' to quit.")
        print("==============================")

        while self.turns > 0 and not self.game_over:

            raw = input(
                f"{self.turns} turns left > "
            ).strip()

            # Quit without changing game state
            if raw.lower() == "q":
                print("\nGame quit.")
                self.game_over = True
                return

            # Invalid input does not consume a turn
            if not self.valid_guess(raw):
                print(
                    f"Enter exactly {self.code_length} digits "
                    f"from 1 to {self.symbol_max}."
                )
                continue

            guess = list(raw)

            exact, partial = feedback(self.code, guess)

            # Only accepted guesses are stored
            self.history.append(
                (raw, exact, partial)
            )

            self.turns -= 1

            print(
                f"Exact: {exact}  Partial: {partial}"
            )

            # Win condition
            if exact == self.code_length:
                self.won = True
                self.game_over = True

                print("\n🎉 Cracked the code!")
                print(f"Code: {''.join(self.code)}")
                self.display_history()
                return

            self.display_history()

        # Loss condition
        if not self.won and self.game_over is False:
            self.game_over = True

            print("\n❌ Out of turns!")
            print(f"The code was: {''.join(self.code)}")
            self.display_history()