def feedback(code, guess):
    """
    Return (exact, partial) matches.

    Exact matches are counted first.
    Each code/guess position can contribute at most once.
    """

    exact = 0
    remaining_code = []
    remaining_guess = []

    # First: exact matches
    for c, g in zip(code, guess):
        if c == g:
            exact += 1
        else:
            remaining_code.append(c)
            remaining_guess.append(g)

    # Second: partial matches
    partial = 0

    for guess_symbol in remaining_guess:
        if guess_symbol in remaining_code:
            partial += 1
            remaining_code.remove(guess_symbol)

    return exact, partial